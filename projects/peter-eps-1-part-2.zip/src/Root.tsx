import React from 'react';
import {Audio,Composition,Sequence,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {Video} from './Video';
import {theme} from './theme';
import timing from './timing.json';
const OFFSET=64.5;
export const RemotionRoot=()=> <Composition id="PeterEpisode1" component={Comp} durationInFrames={Math.ceil((timing as any).duration*theme.fps)} fps={theme.fps} width={theme.width} height={theme.height}/>;
function Comp(){const frame=useCurrentFrame();const {fps}=useVideoConfig();const t=frame/fps+OFFSET; return <><Video t={t}/><Audio src={staticFile('narasi.mp3')} startFrom={Math.floor(OFFSET*fps)} volume={1}/><Audio src={staticFile('backsound.mp3')} startFrom={Math.floor(OFFSET*fps)} volume={0.13} loop/><Sequence from={Math.floor(59.5*fps)} durationInFrames={Math.ceil(1.2*fps)}><Audio src={staticFile("door.mp3")} volume={0.5} /></Sequence></>}
